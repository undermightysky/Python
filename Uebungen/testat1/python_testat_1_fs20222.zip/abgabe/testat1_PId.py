# -*- coding: utf-8 -*-

from storage_lib import Storage

# --- Implementierung Testat --------------------------------------------------
# Implementieren Sie hier die beiden Klassen ModuleBuilder
# und MissingModuleError.


# --- Testcode ----------------------------------------------------------------
# Fügen Sie hier Ihren Testcode ein. Nutzen Sie dafür unter anderem die
# Code-Beispiele in den grauen Boxen der Aufgabenstellung.
if __name__ == '__main__':
    pass
