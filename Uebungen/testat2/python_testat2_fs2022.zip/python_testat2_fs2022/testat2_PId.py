# -*- coding: utf-8 -*-


# --- Implementierung Testat --------------------------------------------------
# Implementieren Sie hierdie Lösung für die zweite Testataufgabe.

# --- Testcode ----------------------------------------------------------------
# Fügen Sie hier Ihren Testcode ein. Nutzen Sie dafür unter anderem die
# Code-Beispiele in den grauen Boxen der Aufgabenstellung sowie auch die
# Angaben in den *.results Files im abgegebenen Ordner.
if __name__ == '__main__':
    pass
